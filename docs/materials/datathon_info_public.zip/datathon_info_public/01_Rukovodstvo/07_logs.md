# Журналы: что читать и как объяснять жюри


Файлы: `C:\Users\GGG\Desktop\datathon\ChipTrack-work\runtime\logs`. Формат JSONL: одна запись JSON на строку. Каждая запись содержит время, поток, событие и дополнительные поля.

| Поток | Основные события | Что показывают |
|---|---|---|
| inference | model_loading, model_ready | Какие локальные модели загружаются и готов ли анализатор |
| inference | queued, analysis_started | Идентификатор задания, очередь, версия и ожидание |
| inference | stage, temporal_window | Этап проверки, временной отрезок, контекст, визуальные оценки |
| inference | handover_geometry | Дополнительная проверка контакта рук |
| inference | analysis_finished / analysis_failed | Вердикт, полнота, длительность либо ошибка |
| training | queued, dataset_ready | Запуск кандидата, родитель, набор, количество видео/окон, хеш |
| training | epoch | Реальная эпоха и loss, не искусственная анимация |
| training | fold_evaluated | Проверенная группа видео |
| training | completed / failed | Метрики и допуск к выпуску либо ошибка |
| versions | feedback_submitted, training_choice_changed | Исправление человека и выбор обучения |
| versions | feedback_reviewed, candidate_created | Одобрение/отклонение разметки и создание кандидата |
| versions | released, rollback, code_updated | Фактическое изменение рабочей версии |
| all | Все перечисленные | Общая последовательность событий |

Отдельные технические файлы: `runtime/server.stdout.log`, `runtime/server.stderr.log`, `runtime/logs/training-process.log`. Журнал туннеля имеет имя `tunnel-ДАТА-ВРЕМЯ.log`; актуальный путь записан в `runtime/public-tunnel.json`.

В логах время UTC; локальное Asia/Qyzylorda — UTC+5. Например, 17 октября 20:13 UTC = 18 октября 01:13 местного времени. В интерфейсе дата показывается по часовому поясу браузера пользователя.

## Три вкладки демонстрации

1. Анализ: показать `model_ready`, потом `queued → analysis_started → analysis_finished` для нового job_id.
2. Обучение: показать `dataset_ready`, эпохи, группы и `completed`.
3. Версии: показать `candidate_created` и `release_eligible: false` у неудачного кандидата. Нового `released` в таком случае не должно быть.

Если обучение завершилось за долю секунды, журнал всё равно сохраняет этапы. Не нужно замедлять его искусственно для демонстрации. Если новых задач нет, отсутствие новых строк нормально. Снимки последних строк для ознакомления включены в `02_Otchety/log-excerpts`; это не живые потоки.

Чтобы связать ответ API с логами, ищите одинаковый `job_id`. Чтобы объяснить, почему два анализа отличаются, сравните `model_version`, код/набор признаков, полноту анализа, события и источники разметки.
