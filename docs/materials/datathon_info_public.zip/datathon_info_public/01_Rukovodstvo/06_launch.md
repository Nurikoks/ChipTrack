# Запуск, остановка и все основные команды


## Самый простой запуск

Рабочая папка: `C:\Users\GGG\Desktop\datathon\ChipTrack-work`.

| Файл в рабочей папке | Действие |
|---|---|
| `Start-ChipTRick.cmd` | Запуск сайта в окне терминала; закрытие процесса/CTRL+C останавливает его |
| `Start-Background.cmd` | Фоновый запуск сайта без отдельного видимого окна |
| `Stop-Background.cmd` | Остановка фонового сайта, записанного его скриптом |
| `Start-Public.cmd` | Запуск сайта при необходимости и публичного туннеля |
| `Public-Status.cmd` | Проверка актуального публичного адреса |
| `Stop-Public.cmd` | Остановка только туннеля, локальный сайт остаётся |
| `Jury-Three-Tabs.cmd` | Три вкладки журналов при наличии Windows Terminal |
| `Logs-Inference.cmd` / `Logs-Training.cmd` / `Logs-Versions.cmd` | Один нужный журнал |
| `Logs-All.cmd` | Совмещённый журнал |

После старта открыть http://127.0.0.1:8000 и дождаться «Модель готова». Загрузка весов в GPU занимает время. Повторный штатный запуск обнаруживает уже работающий сервер. Не запускайте дополнительный экземпляр анализа без необходимости: он также потребует видеопамять.

## Команды PowerShell

В каждой новой консоли сначала перейти в рабочую папку:

```powershell
Set-Location 'C:\Users\GGG\Desktop\datathon\ChipTrack-work'
```

Состояние сервера без изменения данных:

```powershell
Invoke-RestMethod 'http://127.0.0.1:8000/health'
```

Операторские команды (вызывают инициализацию схемы/версии; это не универсальные read-only запросы):

```powershell
.\.venv\Scripts\python.exe -m app.cli status
.\.venv\Scripts\python.exe -m app.cli versions
.\.venv\Scripts\python.exe -m app.cli report
.\.venv\Scripts\python.exe -m app.cli changes
.\.venv\Scripts\python.exe -m app.cli logs inference --follow
.\.venv\Scripts\python.exe -m app.cli logs training --follow
.\.venv\Scripts\python.exe -m app.cli logs versions --follow
.\.venv\Scripts\python.exe -m app.cli logs all --follow
```

Команды, запускающие работу или меняющие версию:

```powershell
.\.venv\Scripts\python.exe -m app.cli train
.\.venv\Scripts\python.exe -m app.cli evaluate
.\.venv\Scripts\python.exe -m app.cli release candidate-REAL_ID --reason "Проверены отчёт и ошибки"
.\.venv\Scripts\python.exe -m app.cli rollback rules-2.0-REAL_HASH --reason "Возврат к проверенной версии"
```

В примерах `REAL_ID` и `REAL_HASH` — заменяемые значения, не готовые идентификаторы. Выпуск возможен только при пройденной проверке и совместимости с текущим кодом. Запуск `evaluate` загружает модели отдельно и использует GPU: полный прогон лучше выполнять без обслуживающего сервера, чтобы не получить нехватку памяти. Он обновляет отчёты и seed-признаки; совместимые полные результаты могут браться из кеша. Это не всегда повторный расчёт каждого видео.

Проверка автоматических сценариев на отдельной временной БД:

```powershell
.\.venv\Scripts\python.exe -m pytest tests -q --basetemp runtime\pytest-manual-check
```

`--basetemp` должен указывать на отдельную папку тестов: pytest может очищать её. Не указывайте `runtime`, папку проекта или каталог с нужными файлами.

Создание ещё одного администратора оператором:

```powershell
.\.venv\Scripts\python.exe -m app.cli create-user operator2 --admin
```

Пароль вводится интерактивно, не записывается в аргументы команды. CLI имеет полномочия владельца локального компьютера; это не публичный API для обычного пользователя.
